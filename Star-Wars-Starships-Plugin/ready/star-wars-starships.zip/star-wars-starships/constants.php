<?php

// Define the Starships API URL
define('STARSHIPS_API_URL', 'https://swapi.dev/api/starships/');
define('STARSHIPS_VERSION', '1.0.0');